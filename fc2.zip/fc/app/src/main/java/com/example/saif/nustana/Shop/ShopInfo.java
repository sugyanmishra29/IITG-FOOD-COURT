package com.example.saif.nustana.Shop;

public final class ShopInfo {

    //constant class to retrieve shopInfo
    public static String shopName;
    public static String shopNumber;
    public static String shopAddress;
    public static String shopDescription;
    public static String shopAbout;

    public static void setShopName(String shopName) {
        ShopInfo.shopName = shopName;
    }

    public static void setShopNumber(String shopNumber) {
        ShopInfo.shopNumber = shopNumber;
    }

    public static void setShopAddress(String shopAddress) {
        ShopInfo.shopAddress = shopAddress;
    }

    public static void setShopDescription(String shopDescription) {
        ShopInfo.shopDescription = shopDescription;
    }

    public static void setShopAbout(String shopAbout) {
        ShopInfo.shopAbout = shopAbout;
    }

}
